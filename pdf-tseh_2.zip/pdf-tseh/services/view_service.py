import os
import PyPDF2


class ViewService:
    @staticmethod
    def extract_text(input_path):
        """Извлечение текста из PDF"""
        try:
            print(f'🔄 Извлечение текста из: {input_path}')

            if not os.path.exists(input_path):
                return False, f"Входной файл не найден: {input_path}"

            text = ""
            with open(input_path, 'rb') as file:
                reader = PyPDF2.PdfReader(file)
                for i, page in enumerate(reader.pages):
                    page_text = page.extract_text()
                    if page_text:
                        text += page_text + "\n"

            if not text.strip():
                return False, "Не удалось найти текст в PDF (возможно, это сканированный документ)"

            print(f'✅ Текст успешно извлечен (символов: {len(text)})')
            return True, text

        except Exception as e:
            print(f'❌ Ошибка извлечения текста: {str(e)}')
            import traceback
            traceback.print_exc()
            return False, f"Ошибка: {str(e)}"
