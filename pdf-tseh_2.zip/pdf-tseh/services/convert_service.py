import os
from pdf2docx import Converter


class ConvertService:
    @staticmethod
    def pdf_to_docx(input_path, output_path):
        """Конвертация PDF → DOCX"""
        try:
            print(f'🔄 Начинаем конвертацию PDF → DOCX')
            print(f'   Входной файл: {input_path}')
            print(f'   Выходной файл: {output_path}')
            
            # Проверяем существование входного файла
            if not os.path.exists(input_path):
                return False, f"Входной файл не найден: {input_path}"
            
            print(f'   Размер входного файла: {os.path.getsize(input_path)} байт')
            
            # Создаём конвертер
            cv = Converter(input_path)
            
            # Конвертируем
            cv.convert(output_path)
            cv.close()
            
            # Проверяем, создался ли файл
            if os.path.exists(output_path):
                print(f'✅ Файл успешно создан: {output_path}')
                print(f'   Размер выходного файла: {os.path.getsize(output_path)} байт')
                return True, "Конвертация успешна"
            else:
                print(f'❌ Файл не создан после конвертации')
                return False, "Файл не был создан после конвертации"
                
        except Exception as e:
            print(f'❌ Ошибка конвертации: {str(e)}')
            import traceback
            traceback.print_exc()
            return False, f"Ошибка конвертации: {str(e)}"

    @staticmethod
    def docx_to_pdf(input_path, output_path):
        """Конвертация DOCX → PDF"""
        try:
            print(f'🔄 Начинаем конвертацию DOCX → PDF')
            print(f'   Входной файл: {input_path}')
            print(f'   Выходной файл: {output_path}')
            
            if not os.path.exists(input_path):
                return False, f"Входной файл не найден: {input_path}"
            
            from docx2pdf import convert
            convert(input_path, output_path)
            
            if os.path.exists(output_path):
                print(f'✅ Файл успешно создан: {output_path}')
                return True, "Конвертация успешна"
            else:
                return False, "Файл не был создан после конвертации"
                
        except Exception as e:
            print(f'❌ Ошибка конвертации: {str(e)}')
            import traceback
            traceback.print_exc()
            return False, f"Ошибка конвертации: {str(e)}"

    @staticmethod
    def get_output_filename(original_filename, target_format):
        """Генерация имени выходного файла"""
        base_name = os.path.splitext(original_filename)[0]
        return f"{base_name}_converted.{target_format}"