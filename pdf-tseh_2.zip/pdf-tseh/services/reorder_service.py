import os
import PyPDF2

class ReorderService:
    @staticmethod
    def reorder_pdf(input_path, output_path, page_order_str):
        """Изменение порядка страниц в PDF"""
        try:
            print(f'🔄 Изменение порядка страниц: {input_path}')

            if not os.path.exists(input_path):
                return False, f"Входной файл не найден: {input_path}"

            # Парсим строку с порядком страниц (например, "3,1,2")
            try:
                # Пользователь вводит "1,2", а в Python индексы с нуля, поэтому -1
                page_order = [int(x.strip()) - 1 for x in page_order_str.split(',') if x.strip()]
            except ValueError:
                return False, "Неверный формат. Введите номера страниц через запятую (например: 2,1,3)"

            if not page_order:
                return False, "Вы не указали порядок страниц"

            reader = PyPDF2.PdfReader(input_path)
            total_pages = len(reader.pages)
            writer = PyPDF2.PdfWriter()

            for page_num in page_order:
                if page_num < 0 or page_num >= total_pages:
                    return False, f"Ошибка: страницы под номером {page_num + 1} не существует (всего страниц: {total_pages})"
                writer.add_page(reader.pages[page_num])

            with open(output_path, 'wb') as out_file:
                writer.write(out_file)

            print(f'✅ Порядок страниц успешно изменен')
            return True, "Порядок страниц успешно изменен"

        except Exception as e:
            print(f'❌ Ошибка изменения порядка: {str(e)}')
            import traceback
            traceback.print_exc()
            return False, f"Ошибка: {str(e)}"
    @staticmethod
    def get_page_count(input_path):
        """Получение количества страниц в PDF"""
        import PyPDF2
        reader = PyPDF2.PdfReader(input_path)
        return len(reader.pages)