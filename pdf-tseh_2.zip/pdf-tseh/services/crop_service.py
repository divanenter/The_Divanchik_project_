import os
import PyPDF2


class CropService:
    @staticmethod
    def crop_pdf(input_path, output_path, top, bottom, left, right):
        """Обрезка полей PDF (значения передаются в пунктах, 1 мм ≈ 2.83 пункта)"""
        try:
            print(f'🔄 Обрезка PDF: {input_path}')

            if not os.path.exists(input_path):
                return False, f"Входной файл не найден: {input_path}"

            reader = PyPDF2.PdfReader(input_path)
            writer = PyPDF2.PdfWriter()

            # Переводим миллиметры в пункты (если пользователь вводит мм)
            # 1 мм = 2.83465 пунктов
            mm_to_pt = 2.83465
            t = float(top) * mm_to_pt
            b = float(bottom) * mm_to_pt
            l = float(left) * mm_to_pt
            r = float(right) * mm_to_pt

            for page in reader.pages:
                # ✅ ИСПРАВЛЕНИЕ: приводим размеры к float, чтобы избежать ошибки Decimal - float
                width = float(page.mediabox.width)
                height = float(page.mediabox.height)

                # Проверка, чтобы не обрезать больше, чем есть
                if l + r >= width or t + b >= height:
                    return False, "Слишком большие отступы. Страница полностью исчезнет."

                # В PDF координаты идут от левого нижнего угла (0,0)
                # Поэтому верх и право мы вычитаем из общего размера
                page.cropbox.lower_left = (l, b)
                page.cropbox.upper_right = (width - r, height - t)

                writer.add_page(page)

            with open(output_path, 'wb') as out_file:
                writer.write(out_file)

            print(f'✅ Обрезка успешно завершена')
            return True, "Файл успешно обрезан"

        except ValueError:
            return False, "Введите корректные числовые значения для отступов"
        except Exception as e:
            print(f'❌ Ошибка обрезки: {str(e)}')
            import traceback
            traceback.print_exc()
            return False, f"Ошибка: {str(e)}"