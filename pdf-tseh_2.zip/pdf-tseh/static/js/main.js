document.addEventListener('DOMContentLoaded', function() {
    // ========== ПАСХАЛКА ==========
    const logo = document.querySelector('.logo');
    if (logo) {
        let clickCount = 0;
        logo.addEventListener('click', function(e) {
            clickCount++;
            if (clickCount === 5) {
                e.preventDefault();
                window.location.href = '/cats';
                clickCount = 0;
            }
            setTimeout(() => { clickCount = 0; }, 2000);
        });
    }

    // ========== ГЛОБАЛЬНАЯ ПЕРЕМЕННАЯ ДЛЯ ФАЙЛА ==========
    let selectedFile = null;

    // ========== DRAG & DROP ==========
    const uploadAreas = document.querySelectorAll('.upload-area');
    uploadAreas.forEach(function(area) {
        const fileInput = area.querySelector('input[type="file"]');
        if (!fileInput) return;

        area.addEventListener('click', () => fileInput.click());

        area.addEventListener('dragover', (e) => {
            e.preventDefault();
            area.classList.add('dragover');
        });
        area.addEventListener('dragleave', () => area.classList.remove('dragover'));
        area.addEventListener('drop', (e) => {
            e.preventDefault();
            area.classList.remove('dragover');
            if (e.dataTransfer.files.length > 0) {
                handleFiles(e.dataTransfer.files, area);
            }
        });
        fileInput.addEventListener('change', function() {
            if (this.files.length > 0) {
                handleFiles(this.files, area);
            }
        });
    });

    function handleFiles(files, area) {
        if (files.length === 0) return;
        const file = files[0];
        const maxSize = 10 * 1024 * 1024;

        if (file.size > maxSize) {
            alert('Ошибка: файл слишком большой (максимум 10 МБ)');
            return;
        }

        const validTypes = [
            'application/pdf',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        ];
        if (!validTypes.includes(file.type)) {
            alert('Ошибка: неподдерживаемый формат. Используйте PDF или DOCX.');
            return;
        }

        // ✅ Сохраняем файл в глобальную переменную
        selectedFile = file;
        area.querySelector('p').textContent = '✅ Загружен: ' + file.name;
        console.log('Файл выбран:', file.name, file.size, file.type);
    }

    // ========== КОНВЕРТАЦИЯ ==========
    const convertBtn = document.getElementById('convertBtn');
    if (convertBtn) {
        convertBtn.addEventListener('click', async function(e) {
            e.preventDefault();

            // ✅ Проверяем глобальную переменную
            if (!selectedFile) {
                alert('Пожалуйста, загрузите файл');
                return;
            }

            const conversionType = document.querySelector('input[name="conversion"]:checked').value;
            const resultSection = document.getElementById('resultSection');
            const progressFill = document.getElementById('progressFill');
            const statusMessage = document.getElementById('statusMessage');
            const downloadBtn = document.getElementById('downloadBtn');

            // Показать результат и прогресс
            resultSection.style.display = 'block';
            progressFill.style.width = '0%';
            statusMessage.textContent = 'Конвертация...';
            statusMessage.style.color = '#333';
            downloadBtn.style.display = 'none';

            // Имитация прогресса
            let progress = 0;
            const progressInterval = setInterval(() => {
                progress += 10;
                progressFill.style.width = progress + '%';
                if (progress >= 90) clearInterval(progressInterval);
            }, 200);

            // ✅ Правильно формируем FormData
            const formData = new FormData();
            formData.append('file', selectedFile);
            formData.append('conversion_type', conversionType);

            console.log('Отправка файла:', selectedFile.name);
            console.log('Тип конвертации:', conversionType);

            try {
                const response = await fetch('/api/convert', {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();
                console.log('Ответ сервера:', data);

                clearInterval(progressInterval);
                progressFill.style.width = '100%';

                if (response.ok && data.success) {
                    statusMessage.textContent = '✅ ' + data.message;
                    statusMessage.style.color = '#28a745';
                    downloadBtn.href = data.download_url;
                    downloadBtn.style.display = 'inline-block';
                } else {
                    statusMessage.textContent = '❌ ' + (data.error || 'Неизвестная ошибка');
                    statusMessage.style.color = '#DB1A1A';
                }
            } catch (error) {
                console.error('Ошибка:', error);
                clearInterval(progressInterval);
                progressFill.style.width = '100%';
                statusMessage.textContent = '❌ Ошибка соединения с сервером';
                statusMessage.style.color = '#DB1A1A';
            }
        });
    }

    // ========== ОСТАЛЬНЫЕ КНОПКИ (заглушки) ==========
    document.querySelectorAll('.btn-primary').forEach(function(button) {
        if (button.id === 'convertBtn') return;

        button.addEventListener('click', function(e) {
            e.preventDefault();
            const resultSection = this.closest('.tool-container').querySelector('.result-section');
            if (!resultSection) return;

            resultSection.style.display = 'block';
            const progressFill = resultSection.querySelector('.progress-fill');
            let progress = 0;

            const interval = setInterval(() => {
                progress += 10;
                progressFill.style.width = progress + '%';
                if (progress >= 100) {
                    clearInterval(interval);
                    const downloadBtn = resultSection.querySelector('.btn-download');
                    if (downloadBtn) downloadBtn.style.display = 'inline-block';
                }
            }, 200);
        });
    });
});
// ========== ПРОСМОТР TXT (Извлечение текста) ==========
let viewSelectedFile = null;
const viewArea = document.querySelector('.upload-area');
const viewInput = document.getElementById('fileInput');
const viewBtn = document.getElementById('viewBtn');

// Перехватываем файл для этого блока (работает и для клика, и для Drag&Drop)
if (viewArea && viewInput) {
    viewInput.addEventListener('change', function() {
        if (this.files.length > 0) viewSelectedFile = this.files[0];
    });
    viewArea.addEventListener('drop', function(e) {
        if (e.dataTransfer.files.length > 0) viewSelectedFile = e.dataTransfer.files[0];
    });
}

if (viewBtn) {
    viewBtn.addEventListener('click', async function(e) {
        // Берем файл либо из нашего перехвата, либо из инпута
        const file = viewSelectedFile || (viewInput && viewInput.files.length > 0 ? viewInput.files[0] : null);

        if (!file) {
            alert('Пожалуйста, загрузите PDF файл');
            return;
        }

        const resultSection = document.getElementById('resultSection');
        const textContent = document.getElementById('textContent');
        const progressFill = document.querySelector('#resultSection .progress-fill');
        const downloadBtn = document.getElementById('downloadBtn');

        resultSection.style.display = 'block';
        textContent.textContent = '⏳ Извлечение текста...';
        downloadBtn.style.display = 'none';
        progressFill.style.width = '50%';

        const formData = new FormData();
        formData.append('file', file);

        try {
            const response = await fetch('/api/view', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();
            progressFill.style.width = '100%';

            if (response.ok && data.success) {
                textContent.textContent = data.text;
                downloadBtn.style.display = 'inline-block';

                downloadBtn.onclick = function(event) {
                    event.preventDefault();
                    const blob = new Blob([data.text], { type: 'text/plain;charset=utf-8' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    const originalName = file.name.replace(/\.[^/.]+$/, "");
                    a.download = originalName + '.txt';
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);
                };
            } else {
                textContent.textContent = '❌ ' + (data.error || 'Ошибка при извлечении текста');
            }
        } catch (error) {
            console.error('Ошибка:', error);
            textContent.textContent = '❌ Ошибка соединения с сервером';
            progressFill.style.width = '0%';
        }
    });
}

// ========== ИЗМЕНЕНИЕ ПОРЯДКА СТРАНИЦ ==========
let reorderFile = null;
const reorderArea = document.querySelector('.upload-area');
const reorderInput = document.getElementById('fileInput');
const reorderBtn = document.getElementById('reorderBtn');
const pagesGrid = document.getElementById('pagesGrid');

if (reorderArea && reorderInput) {
    reorderInput.addEventListener('change', async function() {
        if (this.files.length > 0) {
            reorderFile = this.files[0];
            await loadPagesForReorder(reorderFile);
        }
    });
    reorderArea.addEventListener('drop', async function(e) {
        if (e.dataTransfer.files.length > 0) {
            reorderFile = e.dataTransfer.files[0];
            await loadPagesForReorder(reorderFile);
        }
    });
}

async function loadPagesForReorder(file) {
    if (!file) return;
    pagesGrid.innerHTML = '<p>⏳ Анализ страниц...</p>';

    const formData = new FormData();
    formData.append('file', file);

    try {
        const response = await fetch('/api/page_count', { method: 'POST', body: formData });
        const data = await response.json();
        if (response.ok && data.success) {
            pagesGrid.innerHTML = '';
            // Рисуем квадратики для каждой страницы
            for (let i = 1; i <= data.count; i++) {
                const div = document.createElement('div');
                div.className = 'page-item';
                div.draggable = true;
                div.dataset.page = i;
                div.textContent = 'Стр. ' + i;
                pagesGrid.appendChild(div);
            }
            setupDragAndDropForPages();
        } else {
            pagesGrid.innerHTML = '<p style="color:red;">Ошибка: ' + (data.error || 'Неизвестная ошибка') + '</p>';
        }
    } catch (e) {
        pagesGrid.innerHTML = '<p style="color:red;">Ошибка соединения</p>';
    }
}

function setupDragAndDropForPages() {
    let draggedItem = null;
    const items = pagesGrid.querySelectorAll('.page-item');

    items.forEach(item => {
        item.addEventListener('dragstart', function() {
            draggedItem = this;
            setTimeout(() => this.classList.add('dragging'), 0);
        });

        item.addEventListener('dragend', function() {
            this.classList.remove('dragging');
            draggedItem = null;
        });

        item.addEventListener('dragover', function(e) {
            e.preventDefault();
            if (this !== draggedItem) {
                // Логика для смены мест при перетаскивании
                const rect = this.getBoundingClientRect();
                const next = (e.clientX - rect.left) / (rect.width) > 0.5;
                if (next) {
                    this.parentNode.insertBefore(draggedItem, this.nextSibling);
                } else {
                    this.parentNode.insertBefore(draggedItem, this);
                }
            }
        });
    });
}

if (reorderBtn) {
    reorderBtn.addEventListener('click', async function(e) {
        if (!reorderFile) {
            alert('Пожалуйста, загрузите PDF файл');
            return;
        }

        const items = pagesGrid.querySelectorAll('.page-item');
        if (items.length === 0) {
            alert('Пожалуйста, дождитесь загрузки страниц');
            return;
        }

        // Собираем текущий порядок страниц
        const order = Array.from(items).map(item => item.dataset.page).join(',');

        const resultSection = document.getElementById('resultSection');
        const progressFill = document.querySelector('#resultSection .progress-fill');
        const downloadBtn = document.getElementById('downloadBtn');

        resultSection.style.display = 'block';
        progressFill.style.width = '50%';
        downloadBtn.style.display = 'none';

        const formData = new FormData();
        formData.append('file', reorderFile);
        formData.append('page_order', order);

        try {
            const response = await fetch('/api/reorder', { method: 'POST', body: formData });
            const data = await response.json();
            progressFill.style.width = '100%';

            if (response.ok && data.success) {
                downloadBtn.href = data.download_url;
                downloadBtn.style.display = 'inline-block';
            } else {
                alert('Ошибка: ' + (data.error || 'Неизвестная ошибка'));
                resultSection.style.display = 'none';
            }
        } catch (error) {
            alert('Ошибка соединения с сервером');
            resultSection.style.display = 'none';
        }
    });
}

// ========== ОБРЕЗКА PDF ==========
let cropFile = null;
const cropArea = document.querySelector('.upload-area');
const cropInput = document.getElementById('fileInput');
const cropBtn = document.getElementById('cropBtn');

// Перехват файла
if (cropArea && cropInput) {
    cropInput.addEventListener('change', function() {
        if (this.files.length > 0) cropFile = this.files[0];
    });
    cropArea.addEventListener('drop', function(e) {
        if (e.dataTransfer.files.length > 0) cropFile = e.dataTransfer.files[0];
    });
}

if (cropBtn) {
    cropBtn.addEventListener('click', async function(e) {
        const file = cropFile || (cropInput && cropInput.files.length > 0 ? cropInput.files[0] : null);

        if (!file) {
            alert('Пожалуйста, загрузите PDF файл');
            return;
        }

        // Получаем значения из полей ввода
        const left = document.getElementById('leftMargin').value || 0;
        const right = document.getElementById('rightMargin').value || 0;
        const top = document.getElementById('topMargin').value || 0;
        const bottom = document.getElementById('bottomMargin').value || 0;

        const resultSection = document.getElementById('resultSection');
        const progressFill = document.querySelector('#resultSection .progress-fill');
        const downloadBtn = document.getElementById('downloadBtn');

        resultSection.style.display = 'block';
        progressFill.style.width = '50%';
        downloadBtn.style.display = 'none';

        const formData = new FormData();
        formData.append('file', file);
        formData.append('left', left);
        formData.append('right', right);
        formData.append('top', top);
        formData.append('bottom', bottom);

        try {
            const response = await fetch('/api/crop', { method: 'POST', body: formData });
            const data = await response.json();
            progressFill.style.width = '100%';

            if (response.ok && data.success) {
                downloadBtn.href = data.download_url;
                downloadBtn.style.display = 'inline-block';
            } else {
                alert('Ошибка: ' + (data.error || 'Неизвестная ошибка'));
                resultSection.style.display = 'none'; // Скрываем прогресс при ошибке
            }
        } catch (error) {
            alert('Ошибка соединения с сервером');
            resultSection.style.display = 'none';
        }
    });
}