document.addEventListener('DOMContentLoaded', function() {
    // ========== ПАСХАЛКА ==========
    const logo = document.querySelector('.logo');
    if (logo) {
        let clickCount = 0;
        logo.addEventListener('click', function(e) {
            clickCount++;
            if (clickCount === 5) {
                e.preventDefault();
                window.location.href = '/cats';
                clickCount = 0;
            }
            setTimeout(() => { clickCount = 0; }, 2000);
        });
    }

    // ========== ГЛОБАЛЬНАЯ ПЕРЕМЕННАЯ ДЛЯ ФАЙЛА ==========
    let selectedFile = null;

    // ========== DRAG & DROP ==========
    const uploadAreas = document.querySelectorAll('.upload-area');
    uploadAreas.forEach(function(area) {
        const fileInput = area.querySelector('input[type="file"]');
        if (!fileInput) return;

        area.addEventListener('click', () => fileInput.click());

        area.addEventListener('dragover', (e) => {
            e.preventDefault();
            area.classList.add('dragover');
        });
        area.addEventListener('dragleave', () => area.classList.remove('dragover'));
        area.addEventListener('drop', (e) => {
            e.preventDefault();
            area.classList.remove('dragover');
            if (e.dataTransfer.files.length > 0) {
                handleFiles(e.dataTransfer.files, area);
            }
        });
        fileInput.addEventListener('change', function() {
            if (this.files.length > 0) {
                handleFiles(this.files, area);
            }
        });
    });

    function handleFiles(files, area) {
        if (files.length === 0) return;
        const file = files[0];
        const maxSize = 10 * 1024 * 1024;

        if (file.size > maxSize) {
            alert('Ошибка: файл слишком большой (максимум 10 МБ)');
            return;
        }

        const validTypes = [
            'application/pdf',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        ];
        if (!validTypes.includes(file.type)) {
            alert('Ошибка: неподдерживаемый формат. Используйте PDF или DOCX.');
            return;
        }

        // ✅ Сохраняем файл в глобальную переменную
        selectedFile = file;
        area.querySelector('p').textContent = '✅ Загружен: ' + file.name;
        console.log('Файл выбран:', file.name, file.size, file.type);
    }

    // ========== КОНВЕРТАЦИЯ ==========
    const convertBtn = document.getElementById('convertBtn');
    if (convertBtn) {
        convertBtn.addEventListener('click', async function(e) {
            e.preventDefault();

            // ✅ Проверяем глобальную переменную
            if (!selectedFile) {
                alert('Пожалуйста, загрузите файл');
                return;
            }

            const conversionType = document.querySelector('input[name="conversion"]:checked').value;
            const resultSection = document.getElementById('resultSection');
            const progressFill = document.getElementById('progressFill');
            const statusMessage = document.getElementById('statusMessage');
            const downloadBtn = document.getElementById('downloadBtn');

            // Показать результат и прогресс
            resultSection.style.display = 'block';
            progressFill.style.width = '0%';
            statusMessage.textContent = 'Конвертация...';
            statusMessage.style.color = '#333';
            downloadBtn.style.display = 'none';

            // Имитация прогресса
            let progress = 0;
            const progressInterval = setInterval(() => {
                progress += 10;
                progressFill.style.width = progress + '%';
                if (progress >= 90) clearInterval(progressInterval);
            }, 200);

            // ✅ Правильно формируем FormData
            const formData = new FormData();
            formData.append('file', selectedFile);
            formData.append('conversion_type', conversionType);

            console.log('Отправка файла:', selectedFile.name);
            console.log('Тип конвертации:', conversionType);

            try {
                const response = await fetch('/api/convert', {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();
                console.log('Ответ сервера:', data);

                clearInterval(progressInterval);
                progressFill.style.width = '100%';

                if (response.ok && data.success) {
                    statusMessage.textContent = '✅ ' + data.message;
                    statusMessage.style.color = '#28a745';
                    downloadBtn.href = data.download_url;
                    downloadBtn.style.display = 'inline-block';
                } else {
                    statusMessage.textContent = '❌ ' + (data.error || 'Неизвестная ошибка');
                    statusMessage.style.color = '#DB1A1A';
                }
            } catch (error) {
                console.error('Ошибка:', error);
                clearInterval(progressInterval);
                progressFill.style.width = '100%';
                statusMessage.textContent = '❌ Ошибка соединения с сервером';
                statusMessage.style.color = '#DB1A1A';
            }
        });
    }

    // ========== ОСТАЛЬНЫЕ КНОПКИ (заглушки) ==========
    document.querySelectorAll('.btn-primary').forEach(function(button) {
        if (button.id === 'convertBtn') return;

        button.addEventListener('click', function(e) {
            e.preventDefault();
            const resultSection = this.closest('.tool-container').querySelector('.result-section');
            if (!resultSection) return;

            resultSection.style.display = 'block';
            const progressFill = resultSection.querySelector('.progress-fill');
            let progress = 0;

            const interval = setInterval(() => {
                progress += 10;
                progressFill.style.width = progress + '%';
                if (progress >= 100) {
                    clearInterval(interval);
                    const downloadBtn = resultSection.querySelector('.btn-download');
                    if (downloadBtn) downloadBtn.style.display = 'inline-block';
                }
            }, 200);
        });
    });
});