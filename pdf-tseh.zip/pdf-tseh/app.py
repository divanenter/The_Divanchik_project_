from flask import Flask, render_template, request, jsonify, send_file
from werkzeug.utils import secure_filename
import os
from pathlib import Path
from services.convert_service import ConvertService

app = Flask(__name__)
app.config['SECRET_KEY'] = 'pdf-tseh-secret-key-2026'

# ✅ Абсолютный путь к папке uploads
BASE_DIR = Path(__file__).parent
app.config['UPLOAD_FOLDER'] = str(BASE_DIR / 'uploads')
app.config['MAX_CONTENT_LENGTH'] = 10 * 1024 * 1024  # 10 MB

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
print(f'📁 Папка загрузок: {app.config["UPLOAD_FOLDER"]}')


# ========== МАРШРУТЫ СТРАНИЦ ==========

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/convert')
def convert():
    return render_template('convert.html')


@app.route('/merge')
def merge():
    return render_template('merge.html')


@app.route('/extract')
def extract():
    return render_template('extract.html')


@app.route('/view')
def view():
    return render_template('view.html')


@app.route('/reorder')
def reorder():
    return render_template('reorder.html')


@app.route('/crop')
def crop():
    return render_template('crop.html')


@app.route('/cats')
def cats():
    return render_template('cats.html')


# ========== API МАРШРУТЫ ДЛЯ КОНВЕРТАЦИИ ==========

@app.route('/api/convert', methods=['POST'])
def api_convert():
    """API для конвертации файлов"""
    if 'file' not in request.files:
        return jsonify({'error': 'Файл не загружен'}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'Файл не выбран'}), 400

    conversion_type = request.form.get('conversion_type')
    if conversion_type not in ['pdf_to_docx', 'docx_to_pdf']:
        return jsonify({'error': 'Неверный тип конвертации'}), 400

    filename = secure_filename(file.filename)
    file_ext = filename.rsplit('.', 1)[-1].lower()

    if conversion_type == 'pdf_to_docx' and file_ext != 'pdf':
        return jsonify({'error': 'Для PDF → DOCX загрузите PDF файл'}), 400
    if conversion_type == 'docx_to_pdf' and file_ext != 'docx':
        return jsonify({'error': 'Для DOCX → PDF загрузите DOCX файл'}), 400

    # Сохранение загруженного файла
    input_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(input_path)
    print(f'✅ Файл сохранён: {input_path}')

    # Определение выходного файла
    target_format = 'docx' if conversion_type == 'pdf_to_docx' else 'pdf'
    output_filename = ConvertService.get_output_filename(filename, target_format)
    output_path = os.path.join(app.config['UPLOAD_FOLDER'], output_filename)
    print(f'📄 Выходной файл будет: {output_path}')

    # Конвертация
    if conversion_type == 'pdf_to_docx':
        success, message = ConvertService.pdf_to_docx(input_path, output_path)
    else:
        success, message = ConvertService.docx_to_pdf(input_path, output_path)

    if not success:
        return jsonify({'error': message}), 500

    if not os.path.exists(output_path):
        return jsonify({'error': 'Файл не был создан после конвертации'}), 500

    print(f'✅ Конвертация успешна: {output_path}')

    return jsonify({
        'success': True,
        'message': message,
        'download_url': f'/api/download/{output_filename}'
    })


@app.route('/api/download/<filename>')
def download_file(filename):
    """Скачивание конвертированного файла"""
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    
    print(f'🔍 Ищем файл: {file_path}')
    print(f'📁 Существует ли: {os.path.exists(file_path)}')
    
    if not os.path.exists(file_path):
        return jsonify({'error': f'Файл не найден: {filename}'}), 404

    return send_file(file_path, as_attachment=True)


# ========== ОБРАБОТКА ОШИБОК ==========

@app.errorhandler(413)
def request_entity_too_large(error):
    return jsonify({'error': 'Файл слишком большой. Максимум 10 МБ'}), 413


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)